README for 425 Assignment 1

Use files as needed:

assignment_1_full_code.m will run training and testing as well as generate sample images (depending on which model has the imagesc line commented out)

gaussian_main.m will run training and testing for gaussian and generate mean images with stddev.
it will also calculate the total error rate

naive_main.m will run training and testing for the naive bayes classifier with eta images.
it will aslos calculate the total error rate