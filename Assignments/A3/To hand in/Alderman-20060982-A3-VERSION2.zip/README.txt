README for ELEC 425 Assignment 3
Nicholas Alderman, 20060982, 16naa5

Please find calculations for parts 1 & 2 in word doc

Run "feedforward_net_tanh.m" to process neural net using tanh activation