function alpha = weighted_sum(X, W) 
    alpha = X * W;
end